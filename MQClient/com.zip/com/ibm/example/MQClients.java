package com.ibm.example;
import java.io.IOException;
import java.util.Hashtable;

import com.ibm.mq.MQAsyncStatus;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;

public class MQClients {
	static private String CHANNEL;
	static private int PORT;
	static private String HOST;
	static private String QMANAGER;
	static private String QUEUE;
	static private String TRUSTSTORE;
	static private String TRUSTSTORE_PW;
	static private Hashtable<String, Object> props = new Hashtable<String, Object>();
	static MQQueueManager qMgr = null;

	static private void putMsgOnQueue(String message) {
		// Disabling IBM cipher suite mapping due to
		// using Oracle Java and not IBM Java
		System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", "false");
		// Enabling SSL debug to view the communication
	//	System.setProperty("javax.net.debug", "all");

		System.setProperty("javax.net.ssl.trustStore", TRUSTSTORE);
		System.setProperty("javax.net.ssl.trustStoreType", "jks");
		System.setProperty("javax.net.ssl.trustStorePassword", TRUSTSTORE_PW);
		System.setProperty("com.ibm.mq.cfg.SSL.outboundSNI", "HOSTNAME");

		props.put(MQConstants.CHANNEL_PROPERTY, CHANNEL);
		props.put(MQConstants.PORT_PROPERTY, PORT);
		props.put(MQConstants.HOST_NAME_PROPERTY, HOST);
		props.put(MQConstants.SSL_CIPHER_SUITE_PROPERTY, "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384");

		try {
			qMgr = new MQQueueManager(QMANAGER, props);

			// MQOO_OUTPUT = Open the queue to put messages
			// MQOO_INPUT_AS_Q_DEF = Using queue-defined defaults
			int openOptions = MQConstants.MQOO_INPUT_AS_Q_DEF | MQConstants.MQOO_OUTPUT;

			// creating destination
			MQQueue queue = qMgr.accessQueue(QUEUE, openOptions);

			// specify the message options...
			MQPutMessageOptions pmo = new MQPutMessageOptions(); // Default

			// MQPMO_ASYNC_RESPONSE = MQPUT operation is completed without the
			// application waiting for the queue manager to complete the call
			// Using this option can improve messaging performance,
			// particularly for applications using localhost bindings.
			//pmo.options = MQConstants.MQPMO_ASYNC_RESPONSE;

			// create message
			MQMessage mqMessage = new MQMessage();

			System.out.println("Writing message to queue: " + QUEUE);
			mqMessage.writeString(message);

			// Put message on queue
			queue.put(mqMessage, pmo);

			// Close queue
			queue.close();

			// Get status
			MQAsyncStatus asyncStatus = qMgr.getAsyncStatus();

			// Print status code (0 = successful)
			System.out.println(asyncStatus.reasonCode);

		} catch (MQException e) {
			System.out.println("The connection to MQ could not be established." + e.getMessage());
		} catch (IOException e) {
			System.out.println("Error while writing message." + e.getMessage());
		} finally {
			try {
				qMgr.disconnect();
			} catch (MQException e) {
				System.out.println("The connection could not be closed." + e.getMessage());
			}
		}
	}

	static private void getMsgsFromQueue() {
		// Disabling IBM cipher suite mapping due to
		// using Oracle Java and not IBM Java
		System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", "false");
		// Enabling SSL debug to view the communication
	//	System.setProperty("javax.net.debug", "all");

		System.setProperty("javax.net.ssl.trustStore", TRUSTSTORE);
		System.setProperty("javax.net.ssl.trustStoreType", "jks");
		System.setProperty("javax.net.ssl.trustStorePassword", TRUSTSTORE_PW);
		System.setProperty("com.ibm.mq.cfg.SSL.outboundSNI", "HOSTNAME");

		props.put(MQConstants.CHANNEL_PROPERTY, CHANNEL);
		props.put(MQConstants.PORT_PROPERTY, PORT);
		props.put(MQConstants.HOST_NAME_PROPERTY, HOST);
		// props.put(MQConstants.USER_ID_PROPERTY, USER);
		// props.put(MQConstants.PASSWORD_PROPERTY, "secret"); 
		props.put(MQConstants.SSL_CIPHER_SUITE_PROPERTY, "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384");

		try {
			qMgr = new MQQueueManager(QMANAGER, props);

			// MQOO_INPUT_SHARED = Open the queue to read messages
			int openOptions = MQConstants.MQOO_INPUT_SHARED;

			// creating destination
			MQQueue queue = qMgr.accessQueue(QUEUE, openOptions);

			// specify the message options...
			MQGetMessageOptions gmo = new MQGetMessageOptions(); // Default
			gmo.options = MQConstants.MQPMO_ASYNC_RESPONSE;

			// create message
			MQMessage mqMessage = new MQMessage();

			// Get message from queue
			System.out.println("Fetching message from queue: " + QUEUE);
			queue.get(mqMessage, gmo);

			// Get a message from MQMessage
			String message = mqMessage.readStringOfByteLength(mqMessage.getMessageLength());

			// Display message
			System.out.println(message);

			// Close queue
			queue.close();

			// Get status
			MQAsyncStatus asyncStatus = qMgr.getAsyncStatus();

			// Print status code (0 = successful)
			System.out.println(asyncStatus.reasonCode);

		} catch (MQException e) {
			System.out.println("The connection to MQ could not be established." + e.getMessage());
		} catch (IOException e) {
			System.out.println("Error while fetching the message." + e.getMessage());
		} finally {
			try {
				qMgr.disconnect();
			} catch (MQException e) {
				System.out.println("The connection could not be closed." + e.getMessage());
			}
		}
	}

	public static void main(String[] args) {

		if (args.length != 7) {
			System.out.print("usage: java com.ibm.example.MQClients host port channel qmgr queue truststore trustorePassword");
			System.exit(1);
		}
		
		HOST = args[0];
		PORT = Integer.parseInt(args[1]);
		CHANNEL = args[2];
		QMANAGER = args[3];
		QUEUE = args[4];
		TRUSTSTORE = args[5];
		TRUSTSTORE_PW = args[6];
		
		putMsgOnQueue("hello world");
		getMsgsFromQueue();
	}
}
